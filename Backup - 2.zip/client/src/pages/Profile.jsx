import React from 'react';
import JobSeekerProfileForm from '../components/JobSeekerProfileForm';

const Profile = () => {
  return <JobSeekerProfileForm />;
};

export default Profile;
