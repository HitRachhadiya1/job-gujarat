// frontend/src/App.jsx
import { useEffect, useState } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CompanyDetailsForm from "./components/CompanyDetailsForm";
import CompanyDashboard from "./components/CompanyDashboard";
import RoleSelection from "./pages/RoleSelection";

function App() {
  const {
    isAuthenticated,
    isLoading,
    loginWithRedirect,
    getAccessTokenSilently,
    user,
  } = useAuth0();
  const [companyStatus, setCompanyStatus] = useState(null);
  const [statusLoading, setStatusLoading] = useState(true);

  useEffect(() => {
    const checkCompanyStatus = async () => {
      try {
        setStatusLoading(true);
        const token = await getAccessTokenSilently();

        const response = await fetch(
          "http://localhost:5000/api/company/status",
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        if (!response.ok) throw new Error("Failed to check status");

        const data = await response.json();
        setCompanyStatus(data);
      } catch (error) {
        console.error("Error checking company status:", error);
      } finally {
        setStatusLoading(false);
      }
    };

    if (isAuthenticated) {
      checkCompanyStatus();
    } else {
      setStatusLoading(false);
    }
  }, [isAuthenticated, getAccessTokenSilently]);

  if (isLoading || statusLoading) return <div>Loading...</div>;

  const handleRoleSelected = async (role) => {
    try {
      const token = await getAccessTokenSilently();
      const { sub: userId } = await user;
      const response = await fetch(
        "http://localhost:5000/api/auth/assign-role",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ role, userId }),
        }
      );

      if (!response.ok) throw new Error("Failed to assign role");

      // Refresh company status after role assignment
      checkCompanyStatus();
    } catch (error) {
      console.error("Error assigning role:", error);
      throw error;
    }
  };

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            isAuthenticated ? (
              companyStatus?.exists ? (
                companyStatus.profileCompleted ? (
                  <CompanyDashboard />
                ) : (
                  <CompanyDetailsForm />
                )
              ) : (
                <RoleSelection onRoleSelected={handleRoleSelected} />
              )
            ) : (
              <div className="login-container">
                <h2>Welcome to Job Gujarat</h2>
                <button
                  onClick={() => loginWithRedirect()}
                  className="login-button"
                >
                  Log In / Sign Up
                </button>
              </div>
            )
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
