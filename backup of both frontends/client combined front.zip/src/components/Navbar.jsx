import React from 'react';
import { useAuth0 } from "@auth0/auth0-react";
import { useAuthMeta } from "../context/AuthMetaContext";
import { Button } from "@/components/ui/button";
import { Briefcase, LogOut } from "lucide-react";

const Navbar = () => {
  const { logout, user } = useAuth0();
  const { role } = useAuthMeta();

  const handleLogout = () => {
    logout({ returnTo: window.location.origin });
  };

  return (
    <nav className="bg-white/90 backdrop-blur-sm border-b border-slate-200/50 shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-slate-700 rounded-lg flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-slate-800 to-blue-700 bg-clip-text text-transparent">
                JobPortal Pro
              </h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {user && (
              <span className="text-sm text-slate-600">
                Welcome, {user.name?.split(' ')[0] || 'User'}
              </span>
            )}
            {role && (
              <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                {role}
              </span>
            )}
            <Button onClick={handleLogout} variant="ghost" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
