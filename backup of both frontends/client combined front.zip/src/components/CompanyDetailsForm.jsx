import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const CompanyDetailsForm = ({ refreshAuthMeta, onSuccess }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="container mx-auto max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>Complete Company Profile</CardTitle>
            <CardDescription>Please provide your company details to continue</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 mb-4">Company details form coming soon...</p>
            <Button onClick={onSuccess}>Continue to Dashboard</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CompanyDetailsForm;
