import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const JobManagement = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="container mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Job Management</CardTitle>
            <CardDescription>Manage your job postings and applications</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600">Job management features coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default JobManagement;
