import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const BrowseJobs = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="container mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Browse Jobs</CardTitle>
            <CardDescription>Find your perfect job opportunity</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600">Job browsing features coming soon...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BrowseJobs;
