const { expressjwt: jwt } = require("express-jwt");
const jwksRsa = require("jwks-rsa");
const { getManagementToken } = require("../services/auth0Service");
const axios = require("axios");

const jwtCheck = jwt({
  secret: jwksRsa.expressJwtSecret({
    cache: true,
    rateLimit: true,
    jwksRequestsPerMinute: 5,
    jwksUri: `https://${process.env.AUTH0_DOMAIN}/.well-known/jwks.json`,
  }),
  audience: process.env.AUTH0_AUDIENCE,
  issuer: `https://${process.env.AUTH0_DOMAIN}/`,
  algorithms: ["RS256"],
});

// Middleware to add user role to req.user
const addUserRole = async (req, res, next) => {
  try {
    if (req.user && req.user.sub) {
      const token = await getManagementToken();
      const response = await axios.get(
        `https://${process.env.AUTH0_DOMAIN}/api/v2/users/${req.user.sub}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // Add role to req.user object
      req.user.role = response.data.app_metadata?.role || null;
    }
    next();
  } catch (error) {
    console.error("Error fetching user role:", error);
    // Continue without role if there's an error
    next();
  }
};

// Combined middleware that checks JWT and adds role
const jwtWithRole = [jwtCheck, addUserRole];

module.exports = jwtWithRole;
