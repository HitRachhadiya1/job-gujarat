const express = require("express");
const { assignRole, getUserRole } = require("../controllers/authController");
const jwtWithRole = require("../middleware/jwtAuth");
const router = express.Router();

router.post("/assign-role", jwtWithRole, assignRole);
router.get("/get-role", jwtWithRole, getUserRole);

module.exports = router;
