const express = require("express");
const {
  createJobPosting,
  updateJobPosting,
  deleteJobPosting,
  getJobList,
} = require("../controllers/jobPostingController");
const { requireRole } = require("../middleware/roleAuth");
const jwtCheck = require("../middleware/jwtAuth");

const router = express.Router();
// Get all job postings (accessible by any authenticated user)
router.get("/", jwtCheck, getJobList);

router.post("/", jwtCheck, requireRole("ADMIN", "COMPANY"), createJobPosting);
router.put("/:id", jwtCheck, requireRole("ADMIN", "COMPANY"), updateJobPosting);
router.delete(
  "/:id",
  jwtCheck,
  requireRole("ADMIN", "COMPANY"),
  deleteJobPosting
);

module.exports = router;
