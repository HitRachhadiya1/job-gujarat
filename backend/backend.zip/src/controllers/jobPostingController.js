const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// Admin or company can create a job application
async function createJobPosting(req, res) {
  const { jobId, jobSeekerId, ...data } = req.body;
  const user = req.user;

  // If company, check job belongs to their company
  if (user.role === "COMPANY") {
    const job = await prisma.jobPosting.findUnique({ where: { id: jobId } });
    if (!job || job.companyId !== user.companyId) {
      return res.status(403).json({ error: "Not your job posting" });
    }
  }

  // Only admin or company can create
  if (!["ADMIN", "COMPANY"].includes(user.role)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const app = await prisma.jobApplication.create({
    data: { jobId, jobSeekerId, ...data },
  });
  res.json(app);
}

// Company can update their own job application
async function updateJobPosting(req, res) {
  const { id } = req.params;
  const user = req.user;

  const app = await prisma.jobApplication.findUnique({ where: { id } });
  if (!app) return res.status(404).json({ error: "Not found" });

  // Check ownership
  const job = await prisma.jobPosting.findUnique({ where: { id: app.jobId } });
  if (user.role === "COMPANY" && job.companyId !== user.companyId) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const updated = await prisma.jobApplication.update({
    where: { id },
    data: req.body,
  });
  res.json(updated);
}

// Company can delete their own job application
async function deleteJobPosting(req, res) {
  const { id } = req.params;
  const user = req.user;

  const app = await prisma.jobApplication.findUnique({ where: { id } });
  if (!app) return res.status(404).json({ error: "Not found" });

  const job = await prisma.jobPosting.findUnique({ where: { id: app.jobId } });
  if (user.role === "COMPANY" && job.companyId !== user.companyId) {
    return res.status(403).json({ error: "Forbidden" });
  }

  await prisma.jobApplication.delete({ where: { id } });
  res.json({ success: true });
}

// Get all job postings (for any authenticated user)
async function getJobList(req, res) {
  try {
    const jobs = await prisma.jobPosting.findMany({
      include: {
        company: true, // or select fields as needed
      },
    });
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch job list" });
  }
}

module.exports = {
  createJobPosting,
  updateJobPosting,
  deleteJobPosting,
  getJobList,
};
