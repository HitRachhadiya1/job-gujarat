const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

// Create company (for employer)
async function createCompany(req, res) {
  try {
    const user = req.user; // set by JWT middleware
    if (user.role !== "COMPANY")
      return res
        .status(403)
        .json({ error: `Forbidden User Role is : ${user.role}` });

    // Prevent duplicate company for user
    const existing = await prisma.company.findUnique({
      where: { userId: user.sub },
    });
    if (existing)
      return res
        .status(400)
        .json({ error: "Company already exists for this user" });

    const company = await prisma.company.create({
      data: {
        userId: user.sub, // this is the Auth0 user ID
        name: req.body.name,
        industry: req.body.industry,
        logoUrl: req.body.logoUrl,
        website: req.body.website,
        description: req.body.description,
        // ...add other fields as needed
      },
    });
    res.json(company);
  } catch (err) {
    res.status(500).json({ error: "Failed to create company" });
  }
}

// Get company details for current employer
async function getMyCompany(req, res) {
  try {
    const user = req.user;
    if (user.role !== "COMPANY")
      return res
        .status(403)
        .json({ error: `Forbidden User Role is : ${user.role}` });

    const company = await prisma.company.findUnique({
      where: { userId: user.sub },
    });
    if (!company) return res.status(404).json({ error: "Company not found" });
    res.json(company);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch company" });
  }
}

// Update company (for employer)
async function updateCompany(req, res) {
  try {
    const user = req.user;
    if (user.role !== "COMPANY")
      return res
        .status(403)
        .json({ error: `Forbidden User Role is : ${user.role}` });

    const company = await prisma.company.findUnique({
      where: { userId: user.sub },
    });
    if (!company) return res.status(404).json({ error: "Company not found" });

    const updated = await prisma.company.update({
      where: { userId: user.sub },
      data: req.body,
    });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Failed to update company" });
  }
}

// Delete company (for employer)
async function deleteCompany(req, res) {
  try {
    const user = req.user;
    if (user.role !== "COMPANY")
      return res
        .status(403)
        .json({ error: `Forbidden User Role is : ${user.role}` });

    const company = await prisma.company.findUnique({
      where: { userId: user.sub },
    });
    if (!company) return res.status(404).json({ error: "Company not found" });

    await prisma.company.delete({ where: { userId: user.sub } });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete company" });
  }
}

// Get company status (exists and completion status)
async function getCompanyStatus(req, res) {
  try {
    const user = req.user;
    if (user.role !== "COMPANY")
      return res
        .status(403)
        .json({ error: `Forbidden User Role is : ${user.role}` });

    const company = await prisma.company.findUnique({
      where: { userId: user.sub },
      select: {
        id: true,
        name: true,
        industry: true,
        description: true,
        logoUrl: true,
        website: true,
        verified: true,
      },
    });

    if (!company) {
      return res.json({
        exists: false,
        completed: false,
        company: null,
      });
    }

    // Check if all required fields are filled
    const requiredFields = ["name", "industry", "description"];
    const isCompleted = requiredFields.every(
      (field) => company[field] && company[field].trim() !== ""
    );

    res.json({
      exists: true,
      completed: isCompleted,
      company: company,
    });
  } catch (error) {
    console.error("Error getting company status:", error);
    res.status(500).json({
      message: "Error getting company status",
      error: error.message,
    });
  }
}

module.exports = {
  createCompany,
  getMyCompany,
  updateCompany,
  deleteCompany,
  getCompanyStatus,
};
